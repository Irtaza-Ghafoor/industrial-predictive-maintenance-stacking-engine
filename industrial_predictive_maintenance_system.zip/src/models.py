"""
Custom Stacking Ensemble Architecture
Author: Irtaza Ahmed
"""
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression

class IndustrialEnsembleEngine:
    def __init__(self, config_block):
        self.config = config_block
        self.xgb_base = XGBClassifier(**self.config.XGB_PARAMS)
        self.lgbm_base = LGBMClassifier(**self.config.LGBM_PARAMS)
        self.cat_base = CatBoostClassifier(**self.config.CATBOOST_PARAMS)
        self.meta_learner = LogisticRegression(class_weight='balanced', random_state=self.config.RANDOM_STATE, max_iter=1000)
        self.stacking_classifier = None

    def build_stacking_pipeline(self):
        base_learners = [('xgboost', self.xgb_base), ('lightgbm', self.lgbm_base), ('catboost', self.cat_base)]
        self.stacking_classifier = StackingClassifier(estimators=base_learners, final_estimator=self.meta_learner, cv=5, stack_method='predict_proba', n_jobs=-1)
        return self.stacking_classifier
