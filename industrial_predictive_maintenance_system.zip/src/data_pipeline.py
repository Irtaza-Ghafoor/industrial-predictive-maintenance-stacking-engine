"""
Advanced Data Engineering & Preprocessing Pipeline
Author: Irtaza Ahmed
"""
import numpy as np
import pandas as pd
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer
from sklearn.linear_model import BayesianRidge
from sklearn.preprocessing import StandardScaler

class EnterpriseDataPipeline:
    def __init__(self, configuration_block):
        self.config = configuration_block
        self.mice_imputer = IterativeImputer(estimator=BayesianRidge(), max_iter=self.config.MICE_MAX_ITERATIONS, tol=self.config.MICE_TOLERANCE, random_state=self.config.RANDOM_STATE)
        self.scaler = StandardScaler()
        self.feature_columns = []

    def engineer_sequential_signals(self, dataframe: pd.DataFrame) -> pd.DataFrame:
        processed_df = dataframe.copy()
        processed_df['date'] = pd.to_datetime(processed_df['date'])
        processed_df = processed_df.sort_values(by=['device', 'date']).reset_index(drop=True)
        telemetry_metrics = [col for col in processed_df.columns if processed_df[col].dtype in [np.float64, np.int64] and col not in self.config.EXCLUDE_COLUMNS and col != self.config.TARGET_CLASSIFICATION]
        for metric in telemetry_metrics:
            processed_df[f'{metric}_lag_1'] = processed_df.groupby('device')[metric].shift(1).bfill()
        return processed_df

    def fit_transform(self, X_train: pd.DataFrame) -> pd.DataFrame:
        self.feature_columns = [col for col in X_train.columns if col not in self.config.EXCLUDE_COLUMNS]
        train_matrix = X_train[self.feature_columns].values
        imputed_matrix = self.mice_imputer.fit_transform(train_matrix)
        scaled_matrix = self.scaler.fit_transform(imputed_matrix)
        return pd.DataFrame(scaled_matrix, columns=self.feature_columns, index=X_train.index)

    def transform(self, X_test: pd.DataFrame) -> pd.DataFrame:
        test_matrix = X_test[self.feature_columns].values
        imputed_matrix = self.mice_imputer.transform(test_matrix)
        scaled_matrix = self.scaler.transform(imputed_matrix)
        return pd.DataFrame(scaled_matrix, columns=self.feature_columns, index=X_test.index)
