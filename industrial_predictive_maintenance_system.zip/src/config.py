"""
Project Configuration Module
"""
class ProjectConfig:
    RANDOM_STATE = 42
    TEST_SPLIT_SIZE = 0.25
    TARGET_CLASSIFICATION = 'failure'
    EXCLUDE_COLUMNS = ['date', 'device']
    MICE_MAX_ITERATIONS = 10
    MICE_TOLERANCE = 1e-3
    
    XGB_PARAMS = {'n_estimators': 150, 'learning_rate': 0.05, 'max_depth': 6, 'subsample': 0.8, 'colsample_bytree': 0.8, 'random_state': RANDOM_STATE, 'eval_metric': 'logloss'}
    LGBM_PARAMS = {'n_estimators': 150, 'learning_rate': 0.05, 'num_leaves': 31, 'subsample': 0.8, 'colsample_bytree': 0.8, 'random_state': RANDOM_STATE, 'verbose': -1}
    CATBOOST_PARAMS = {'iterations': 150, 'learning_rate': 0.05, 'depth': 6, 'random_seed': RANDOM_STATE, 'verbose': 0}
